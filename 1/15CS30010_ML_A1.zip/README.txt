Each part's solution is written in a saperate file, named as Ass_1<part_char><subpart_number>_ML.py
Also, since problem a. doesn't have two saperate parts, but has regularization in 2nd and not in first solution, they are stored in Ass_1a_ML_reg.py and Ass_1a_ML.py, respectively.

Each file is well documented through the use of comments in each file.

To execute each file, use:
python3 <filename> 
